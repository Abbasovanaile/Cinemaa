﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            int Sira = 5;
            int Sutun = 6;
            int LeftPos = 166;
            int TopPos = 60;
            for (int i = 0; i < Sira; i++)
            {
                for (int j = 1; j <= Sutun; j++)
                {
                    var a = new Button();
                    a.Left = LeftPos;
                    a.Top = TopPos;
                    a.Width = 40;
                    a.Height = 30;
                    a.Text = ""+j+"";
                    a.BackColor = Color.Red;
                    Controls.Add(a);

                    LeftPos += 40;
                    a.Click += new EventHandler(btn_click);

                }
                LeftPos = 166;
                TopPos += 40;
            }
        }
        public int count = 0;
        private void btn_click(object sender, EventArgs e)
        {
            count++;
            var a = sender as Button;
            a.BackColor = Color.Black;
        }

        private void button1_Click(object sender, EventArgs e)
        {
        
            MessageBox.Show("Qeydiyyatdan kecdiz");
            MessageBox.Show("Mebleg :"+5*count);
        }
    }
}
