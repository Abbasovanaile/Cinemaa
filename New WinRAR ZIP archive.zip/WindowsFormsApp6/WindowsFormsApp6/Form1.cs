﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            var cinema1 = new Movie("Recep Ivedik", "13 mart 12:00");
            var cinema2 = new Movie("Deliha", "9mart 11:00");
            var cinema3 = new Movie("Kelebek ", "1 mart 12:30");
            var cinema4 = new Movie("Kurtlar Vadisi", "5mart 15:00");
            foreach (var item in Movie.Movies)
            {
                cmb1.Items.Add(item.Title);

            }
            foreach (var item in Movie.Movies)
            {
                cmb2.Items.Add(item.Date);
            }
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            var a = new Form2();
            a.Show();
        }
    }
    class Movie
    {
        public static List<Movie> Movies = new List<Movie>();
        public string Title;
        public string Date;
        public Movie(string _title, string _date)
        {
            Title = _title;
            Date = _date;
            Movies.Add(this);
        }

    }
}
